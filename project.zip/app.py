import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
from datetime import datetime, date

DB="expense_manager.db"

def init_db():
    with sqlite3.connect(DB) as conn:
        c=conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tdate TEXT NOT NULL,
            ttype TEXT CHECK(ttype IN ('Income','Expense')) NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            note TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS budgets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT UNIQUE NOT NULL,
            monthly_limit REAL NOT NULL
        )""")
        conn.commit()

def insert_tx(tdate,ttype,category,amount,note):
    with sqlite3.connect(DB) as conn:
        conn.execute("INSERT INTO transactions(tdate,ttype,category,amount,note) VALUES(?,?,?,?,?)",(tdate,ttype,category,amount,note))
        conn.commit()

def update_tx(tx_id,tdate,ttype,category,amount,note):
    with sqlite3.connect(DB) as conn:
        conn.execute("UPDATE transactions SET tdate=?, ttype=?, category=?, amount=?, note=? WHERE id=?",(tdate,ttype,category,amount,note,tx_id))
        conn.commit()

def delete_tx(tx_id):
    with sqlite3.connect(DB) as conn:
        conn.execute("DELETE FROM transactions WHERE id=?",(tx_id,))
        conn.commit()

def get_df():
    with sqlite3.connect(DB) as conn:
        df=pd.read_sql_query("SELECT * FROM transactions ORDER BY date(tdate) DESC, id DESC",conn,parse_dates=["tdate"])
    return df

def upsert_budget(category,monthly_limit):
    with sqlite3.connect(DB) as conn:
        conn.execute("INSERT INTO budgets(category,monthly_limit) VALUES(?,?) ON CONFLICT(category) DO UPDATE SET monthly_limit=excluded.monthly_limit",(category,monthly_limit))
        conn.commit()

def delete_budget(category):
    with sqlite3.connect(DB) as conn:
        conn.execute("DELETE FROM budgets WHERE category=?",(category,))
        conn.commit()

def get_budgets():
    with sqlite3.connect(DB) as conn:
        return pd.read_sql_query("SELECT * FROM budgets",conn)

def import_csv(file):
    df=pd.read_csv(file)
    cols=[c.lower().strip() for c in df.columns]
    m={k:v for k,v in zip(df.columns,cols)}
    df=df.rename(columns=m)
    need={"tdate","ttype","category","amount"}
    if not need.issubset(set(df.columns)):
        st.error("CSV must have columns: tdate, ttype, category, amount, optional: note")
        return 0
    df["note"]=df.get("note","")
    df["tdate"]=pd.to_datetime(df["tdate"]).dt.strftime("%Y-%m-%d")
    df["ttype"]=df["ttype"].str.title().replace({"Expense":"Expense","Income":"Income"})
    df=df[df["ttype"].isin(["Income","Expense"])].copy()
    df["amount"]=pd.to_numeric(df["amount"],errors="coerce")
    df=df.dropna(subset=["amount"])
    rows=0
    with sqlite3.connect(DB) as conn:
        for _,r in df.iterrows():
            conn.execute("INSERT INTO transactions(tdate,ttype,category,amount,note) VALUES(?,?,?,?,?)",(r["tdate"],r["ttype"],str(r["category"]),float(r["amount"]),str(r["note"])))
            rows+=1
        conn.commit()
    return rows

def export_csv(df):
    return df.to_csv(index=False).encode()

def kpis(df):
    inc=df.loc[df["ttype"]=="Income","amount"].sum()
    exp=df.loc[df["ttype"]=="Expense","amount"].sum()
    bal=inc-exp
    return inc,exp,bal

def month_key(dt):
    return dt.strftime("%Y-%m")

init_db()
st.set_page_config(page_title="Expense Manager Pro",page_icon="💰",layout="wide")

with st.sidebar:
    st.title("💰 Expense Manager Pro")
    st.caption("Advanced Python project with GUI + DB")
    st.divider()
    st.subheader("Add Transaction")
    tdate=st.date_input("Date",value=date.today())
    ttype=st.selectbox("Type",["Expense","Income"])
    category=st.text_input("Category","General")
    amount=st.number_input("Amount",min_value=0.0,step=100.0,format="%.2f")
    note=st.text_input("Note","")
    if st.button("Add"):
        insert_tx(str(tdate),ttype,category,amount,note)
        st.success("Saved")

    st.divider()
    st.subheader("Import CSV")
    up=st.file_uploader("Upload CSV",type=["csv"])
    if up is not None:
        rows=import_csv(up)
        if rows>0:
            st.success(f"Imported {rows} rows")

    st.divider()
    st.subheader("Budgets")
    bcat=st.text_input("Budget Category","Food")
    blim=st.number_input("Monthly Limit",min_value=0.0,step=100.0,format="%.2f")
    c1,c2=st.columns(2)
    with c1:
        if st.button("Save Budget"):
            upsert_budget(bcat,blim)
            st.success("Budget saved")
    with c2:
        if st.button("Delete Budget"):
            delete_budget(bcat)
            st.success("Budget deleted")
    st.caption("CSV columns: tdate, ttype (Income/Expense), category, amount, note")

st.header("Dashboard")

df=get_df()
if df.empty:
    st.info("No data yet. Add a transaction from the sidebar or import a CSV.")
else:
    qcol1,qcol2,qcol3,qcol4=st.columns([2,2,2,3])
    with qcol1:
        dater=st.date_input("Date Range",value=(df["tdate"].min().date(),df["tdate"].max().date()))
    with qcol2:
        ftype=st.multiselect("Type",options=["Income","Expense"],default=["Income","Expense"])
    with qcol3:
        cats=sorted(df["category"].unique().tolist())
        fcat=st.multiselect("Category",options=cats,default=cats)
    with qcol4:
        search=st.text_input("Search Note/Category","")

    mask=(df["tdate"].dt.date>=dater[0])&(df["tdate"].dt.date<=dater[1])&(df["ttype"].isin(ftype))&(df["category"].isin(fcat))
    if search.strip():
        s=search.strip().lower()
        mask=mask & (df["note"].str.lower().str.contains(s)|df["category"].str.lower().str.contains(s))
    fdf=df.loc[mask].copy()

    inc,exp,bal=kpis(fdf)
    k1,k2,k3=st.columns(3)
    k1.metric("Total Income",f"₹{inc:,.2f}")
    k2.metric("Total Expense",f"₹{exp:,.2f}")
    k3.metric("Balance",f"₹{bal:,.2f}")

    mdf=fdf.copy()
    mdf["month"]=mdf["tdate"].dt.to_period("M").astype(str)
    grp=mdf.pivot_table(index="month",columns="ttype",values="amount",aggfunc="sum").fillna(0).reset_index()
    grp=grp.sort_values("month")
    st.subheader("Monthly Trend")
    st.line_chart(grp.set_index("month"))

    st.subheader("Category Breakdown")
    cgrp=mdf[mdf["ttype"]=="Expense"].groupby("category",as_index=False)["amount"].sum().sort_values("amount",ascending=False)
    if not cgrp.empty:
        st.bar_chart(cgrp.set_index("category"))
    else:
        st.caption("No expense rows in current filter.")

    st.subheader("Transactions")
    edf=fdf.copy()
    edf["tdate"]=edf["tdate"].dt.strftime("%Y-%m-%d")
    st.dataframe(edf,use_container_width=True)

    bdf=get_budgets()
    if not bdf.empty:
        st.subheader("Budget Status (Current Month)")
        month_now=pd.Timestamp.today().strftime("%Y-%m")
        cm=mdf[(mdf["ttype"]=="Expense")&(mdf["month"]==month_now)].groupby("category",as_index=False)["amount"].sum().rename(columns={"amount":"spent"})
        bd=bdf.merge(cm,how="left",on="category").fillna({"spent":0.0})
        bd["remaining"]=bd["monthly_limit"]-bd["spent"]
        st.dataframe(bd[["category","monthly_limit","spent","remaining"]].sort_values("remaining"),use_container_width=True)
        over=bd[bd["remaining"]<0]
        if not over.empty:
            st.error("Budget exceeded in: "+", ".join(over["category"].tolist()))

    st.subheader("Edit/Delete")
    ids=edf["id"].tolist()
    if ids:
        sel=st.selectbox("Select Transaction ID",ids)
        row=fdf[fdf["id"]==sel].iloc[0]
        colA,colB=st.columns(2)
        with colA:
            nd=st.date_input("Date (edit)",value=pd.to_datetime(row["tdate"]).date(),key="ed1")
            nt=st.selectbox("Type (edit)",["Expense","Income"],index=0 if row["ttype"]=="Expense" else 1,key="ed2")
            nc=st.text_input("Category (edit)",value=row["category"],key="ed3")
        with colB:
            na=st.number_input("Amount (edit)",value=float(row["amount"]),min_value=0.0,step=100.0,format="%.2f",key="ed4")
            nn=st.text_input("Note (edit)",value=row["note"] if pd.notna(row["note"]) else "",key="ed5")
        e1,e2=st.columns(2)
        with e1:
            if st.button("Update"):
                update_tx(int(sel),str(nd),nt,nc,na,nn)
                st.success("Updated")
        with e2:
            if st.button("Delete"):
                delete_tx(int(sel))
                st.warning("Deleted")

    st.subheader("Export")
    st.download_button("Download CSV",data=export_csv(edf),file_name="transactions_export.csv",mime="text/csv")
